﻿using CategoryAPI.Model;
using Newtonsoft.Json;
using RestSharp;

namespace CategoryAPI.Helper
{
    public class APIIntegrationHelper
    {

        /// <summary>
        /// Gets the popular attributes.
        /// </summary>
        /// <param name="subCategory">The sub category.</param>
        /// <returns></returns>
        /// <exception cref="System.Exception">Internal server error: " + ex.Message</exception>
        public async Task<List<string>> GetPopularAttributes(SubCategory subCategory)
        {
            try
            {
                var client = new RestClient("https://api.openai.com/v1/completions");
                var request = new RestRequest("", Method.Post);
                request.AddHeader("Authorization", "Bearer sk-proj-wrwsRZsAwuVUDq11KQpsT3BlbkFJ7B7srYKyKJs2vLHkvMXw");
                request.AddHeader("Content-Type", "application/json");

                var body = new
                {
                    model = "gpt-3.5-turbo", // Update to a valid and supported model
                    prompt = $"List the most popular attributes for {subCategory.CategoryName}",
                    max_tokens = 50
                };


                request.AddJsonBody(body);

                var response = await client.ExecuteAsync(request);

                if (response.IsSuccessful)
                {
                    var content = JsonConvert.DeserializeObject<dynamic>(response.Content);
                    var attributes = ((string)content.choices[0].text).Split('\n').ToList();
                    return attributes.Where(a => !string.IsNullOrEmpty(a)).ToList();
                }

                return new List<string> { "attribute1", "attribute2", "attribute3" };
            }
            catch (Exception ex)
            {
                throw new Exception("Internal server error: " + ex.Message);
            }
        }
    }
}
