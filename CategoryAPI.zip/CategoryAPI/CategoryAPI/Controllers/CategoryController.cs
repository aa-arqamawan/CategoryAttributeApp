﻿using CategoryAPI.Helper;
using CategoryAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CategoryAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly APIIntegrationHelper _apiIntegrationHelper;

        /// <summary>
        /// Initializes a new instance of the <see cref="CategoryController"/> class.
        /// </summary>
        public CategoryController()
        {
            _apiIntegrationHelper = new APIIntegrationHelper();
        }

        /// <summary>
        /// Processes the categories.
        /// </summary>
        /// <param name="categories">The categories.</param>
        /// <returns></returns>
        /// <exception cref="System.Exception">Internal server error: " + ex.Message</exception>
        [HttpPost]
        public async Task<IActionResult> ProcessCategories([FromBody] List<Category> categories)
        {
            try
            {
                var categoryAttributes = new List<CategoryAttribute>();

                foreach (var category in categories)
                {
                    foreach (var subCategory in category.SubCategories)
                    {
                        var attributes = await _apiIntegrationHelper.GetPopularAttributes(subCategory);
                        categoryAttributes.Add(new CategoryAttribute
                        {
                            CategoryId = subCategory.CategoryId,
                            Attributes = attributes
                        });
                    }
                }

                return Ok(categoryAttributes);
            }
            catch (Exception ex)
            {
                throw new Exception("Internal server error: " + ex.Message);
            }
            
        }
    }
}
